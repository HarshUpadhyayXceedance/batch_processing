package com.example.batch_processing.controller;

import com.example.batch_processing.model.Product;
import com.example.batch_processing.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadProduct(
            @RequestParam("productId") String productId,
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("price") double price,
            @RequestParam("discount") double discount,
            @RequestParam(value = "image", required = false) MultipartFile imageFile) throws IOException {

        Product product = new Product();
        product.setProductId(productId);
        product.setTitle(title);
        product.setDescription(description);
        product.setPrice(price);
        product.setDiscount(discount);

        if (imageFile != null && !imageFile.isEmpty()) {
            product.setImage(imageFile.getBytes());
        }

        productRepository.save(product);
        return ResponseEntity.ok("Product saved successfully");
    }


    @GetMapping
    public List<Map<String, Object>> getAllProducts() {
        return productRepository.findAll().stream().map(product -> {
            Map<String, Object> map = new HashMap<>();
            map.put("productId", product.getProductId());
            map.put("title", product.getTitle());
            map.put("description", product.getDescription());
            map.put("price", product.getPrice());
            map.put("discount", product.getDiscount());

            if (product.getImage() != null) {
                String base64Image = Base64.getEncoder().encodeToString(product.getImage());
                map.put("image", "data:image/jpeg;base64," + base64Image);
            } else {
                map.put("image", null);
            }

            return map;
        }).toList();
    }
}
