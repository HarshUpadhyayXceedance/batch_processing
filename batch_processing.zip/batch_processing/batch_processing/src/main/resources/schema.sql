CREATE  TABLE IF NOT EXISTS products
(
    product_id varchar(100) primary key,
    title varchar(200),
    description varchar(200),
    price double,
    discount double,
    discounted_price double
);

