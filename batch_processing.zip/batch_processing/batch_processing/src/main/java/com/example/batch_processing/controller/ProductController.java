package com.example.batch_processing.controller;

import org.springframework.web.bind.annotation.*;
import com.example.batch_processing.model.Product;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Paths;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/products")
public class ProductController {

    @PostMapping
    public String saveProduct(@RequestBody Product product) {
        String csvFilePath = Paths.get("src/main/resources/products.csv").toString();

        // Calculate discountedPrice dynamically
        double discountAmount = (product.getDiscount() / 100) * product.getPrice();
        product.setDiscountedPrice(product.getPrice() - discountAmount);

        try (FileWriter writer = new FileWriter(csvFilePath, true)) {
            writer.append(product.getProductId())
                    .append(",")
                    .append(product.getTitle())
                    .append(",")
                    .append(product.getDescription())
                    .append(",")
                    .append(String.valueOf(product.getPrice()))
                    .append(",")
                    .append(String.valueOf(product.getDiscount()))
                    .append("\n");
        } catch (IOException e) {
            e.printStackTrace();
            return "Error saving product";
        }

        return "Product saved successfully";
    }
}