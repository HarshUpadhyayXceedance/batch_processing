package com.example.batch_processing.controller;

import com.example.batch_processing.model.Product;
import com.example.batch_processing.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/products")
public class ProductController {
    @Autowired
    private ProductRepository productRepository;
    private static final String CSV_FILE_PATH = "src/main/resources/products.csv";
    @PostMapping
    public String saveProduct(@RequestBody Product product) {
        double discountAmount = (product.getDiscount() / 100) * product.getPrice();
        product.setDiscountedPrice(product.getPrice() - discountAmount);
        try (FileWriter writer = new FileWriter(CSV_FILE_PATH, true)) {
            writer.append(product.getProductId())
                    .append(",")
                    .append(product.getTitle())
                    .append(",")
                    .append(product.getDescription())
                    .append(",")
                    .append(String.valueOf(product.getPrice()))
                    .append(",")
                    .append(String.valueOf(product.getDiscount()))
                    .append("\n");
        } catch (IOException e) {
            e.printStackTrace();
            return "Error saving product to CSV";
        }
        int lineCount = 0;
        try {
            List<String> lines = Files.readAllLines(Paths.get(CSV_FILE_PATH));
            lineCount = lines.size()-1;
        } catch (IOException e) {
            e.printStackTrace();
            return "Error reading CSV file";
        }
        if (lineCount % 5 == 0) {
            try {
                List<Product> products = new ArrayList<>();
                List<String> lines = Files.readAllLines(Paths.get(CSV_FILE_PATH));
                for (int i = 1; i < lines.size(); i++) {
                    String line = lines.get(i);
                    if (line.trim().isEmpty()) continue;
                    String[] parts = line.split(",");
                    if (parts.length < 5) continue;
                    Product p = new Product();
                    p.setProductId(parts[0]);
                    p.setTitle(parts[1]);
                    p.setDescription(parts[2]);
                    p.setPrice(Double.parseDouble(parts[3]));
                    p.setDiscount(Double.parseDouble(parts[4]));
                    double discount = (p.getDiscount() / 100) * p.getPrice();
                    p.setDiscountedPrice(p.getPrice() - discount);
                    products.add(p);
                }
                productRepository.saveAll(products);
                Files.write(Paths.get(CSV_FILE_PATH), new ArrayList<>());
                return "CSV reached 5 entries. Products saved to DB.";
            } catch (Exception e) {
                e.printStackTrace();
                return "Error saving products to DB";
            }
        }
        return "Product saved to CSV only (waiting for 5 total to save in DB)";
    }
}
