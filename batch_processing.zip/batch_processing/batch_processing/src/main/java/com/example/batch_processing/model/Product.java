package com.example.batch_processing.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    private String productId;
    private String title;
    private String description;

    private double price;

    private double discount;

    private  double discountedPrice;

}
