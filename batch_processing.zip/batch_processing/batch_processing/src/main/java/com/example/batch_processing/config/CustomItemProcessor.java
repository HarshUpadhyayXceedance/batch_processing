package com.example.batch_processing.config;
import org.springframework.batch.item.ItemProcessor;

import com.example.batch_processing.model.Product;

public class CustomItemProcessor implements ItemProcessor<Product, Product> {
    @Override
    public Product process(Product item) throws Exception {
        try {
            System.out.println(item.getDescription());
            double discountPer = item.getDiscount();
            double originalPrice = item.getPrice();
            double discount = (discountPer / 100) * originalPrice;
            double finalPrice = originalPrice - discount;
            item.setDiscountedPrice(finalPrice);
        } catch (
                NumberFormatException ex
        ) {
            ex.printStackTrace();
        }

        return item;
    }
}
