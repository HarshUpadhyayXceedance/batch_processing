import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-product-detail-form',
  imports: [ReactiveFormsModule],
  templateUrl: './product-detail-form.component.html',
  styleUrls: ['./product-detail-form.component.css']
})
export class ProductDetailFormComponent {
  productForm: FormGroup;
  selectedFile: File | null = null;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.productForm = this.fb.group({
      productId: [''],
      title: [''],
      description: [''],
      price: [''],
      discount: ['']
    });
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  submitProduct() {
    const formData = new FormData();
    const formValues = this.productForm.value;

    formData.append('productId', formValues.productId);
    formData.append('title', formValues.title);
    formData.append('description', formValues.description);
    formData.append('price', formValues.price);
    formData.append('discount', formValues.discount);

    if (this.selectedFile) {
      formData.append('image', this.selectedFile);
    }

    this.http.post('http://localhost:8080/api/products/upload', formData)
      .subscribe({
        next: res => console.log('Product uploaded successfully', res),
        error: err => console.error('Upload failed', err)
      });
  }
}
