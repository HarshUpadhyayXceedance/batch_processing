import { Component } from '@angular/core';
import { ProductDetailFormComponent } from "./component/product-detail-form/product-detail-form.component";
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'product';
}
