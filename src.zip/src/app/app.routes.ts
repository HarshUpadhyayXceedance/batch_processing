import { Routes } from '@angular/router';
import { ProductListComponent } from './component/product-list/product-list.component';
import { ProductDetailFormComponent } from './component/product-detail-form/product-detail-form.component';

export const routes: Routes = [
{path: '',component: ProductListComponent},
{path: 'upload',component: ProductDetailFormComponent},
];
